import React from 'react';


function Best() {
  return (
      <div className="container">

            <h1>Best</h1>

      </div>
  );
}

export default Best;
