import React from 'react';
import './login.css';


function Login() {
  return (
      <div className="container">
        <h1 className='login-benner'>Login</h1>
        <form className="login-form">
                
                <input
                className='idpw'
                type="text"
                id="username"
                placeholder = "E-mail"
                />

                
                <input
                className='idpw'
                type="password"
                id="password"
                placeholder = "Password"
                />
        </form>
        <div className='submit-button'>
            <button className='login-button'>회원가입</button>
            <button className='login-button'>로그인</button>
        </div>
      </div>
  );
}

export default Login;
