import React from 'react';


function Outer() {
  return (
      <div className="container">

            <h1>Outer</h1>

      </div>
  );
}

export default Outer;
