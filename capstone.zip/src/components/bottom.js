import React from 'react';


function Bottom() {
  return (
      <div className="container">

            <h1>Bottom</h1>

      </div>
  );
}

export default Bottom;
