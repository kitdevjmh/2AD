import React from 'react';


function Top() {
  return (
      <div className="container">

            <h1>Top</h1>

      </div>
  );
}

export default Top;
